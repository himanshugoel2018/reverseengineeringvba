import azure.functions as func
import logging
import os  
import openai
# from azure.identity import DefaultAzureCredential, get_bearer_token_provider

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

openai.api_type = "azure"
openai.azure_endpoint = os.getenv("ENDPOINT_URL", "https://hgoelazureopenai1.openai.azure.com/")
openai.api_key = os.getenv("AZURE_OPENAI_API_KEY", "B1wzJqPz2NeGPuA3i3fd8dVbhImWcIBoqGDmJ3mzuDAZf6mt3095JQQJ99ALACYeBjFXJ3w3AAABACOGv568")
openai.api_version = "2024-05-01-preview"  # Or the version you're using

# endpoint = os.getenv("ENDPOINT_URL", "https://hgoelazureopenai1.openai.azure.com/")  
deployment = os.getenv("DEPLOYMENT_NAME", "gpt-35-turbo-hgoel")  
# subscription_key = os.getenv("AZURE_OPENAI_API_KEY", "B1wzJqPz2NeGPuA3i3fd8dVbhImWcIBoqGDmJ3mzuDAZf6mt3095JQQJ99ALACYeBjFXJ3w3AAABACOGv568") 

# Set OpenAI API credentials
# openai.api_base = endpoint
# openai.api_key = subscription_key

@app.route(route="funcvbaunderstand")
def funcvbaunderstand(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    try:
        try: 
            # Retrieve POST body 
            # req_body = req.get_json() 
            vba_code = req.get_body().decode('utf-8') 
        except ValueError: 
            return func.HttpResponse( "Invalid JSON", status_code=400 ) 
        
        # Prepare the chat prompt  
        chat_prompt = [
        {"role": "user", "content": f"Please analyze this VBA code: {vba_code}"}]  

        # Generate the completion  
        completion = openai.chat.completions.create(  
            messages=chat_prompt,
            model=deployment,
            max_tokens=800,
            temperature=0.7
        )
        response_data = completion.choices[0].message.content.strip()
        # Return the response as JSON
        return func.HttpResponse(
            response_data,
            status_code=200,
            mimetype="application/json"
        )
    except Exception as e: 
        logging.error(f"Error: {str(e)}") 
        return func.HttpResponse(
            "An error occurred", 
            status_code=500)